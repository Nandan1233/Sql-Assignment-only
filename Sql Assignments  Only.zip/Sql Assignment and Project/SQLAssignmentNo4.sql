
-----------Create table students(studentid int , name varchar(max) , surname varchar(max) , birthdate int , gender varchar(max) ,
-----class int , point int )

--------Insert into students(studentid , name , surname , birthdate ,gender , class ,point)
------values(1 , 'kajal' , 'Gupta' , 21/02/23 , 'female' , 10 , 3) ,
------(1 , 'Rahul' , 'Yadav' , 01/05/23 , 'Male' , 50 , 6) 

---------Assignment 4--------------------
--------1----------
select * from students

------2---------------
select name, surname, class from students

------3--------------
select * from students where gender='Female'

----------4--------------
select distinct class from students

-------5------------------
select * from students where gender='F' and class='10Math'

--------6--------------
select name, surname, class from students
where class='10Math' or class='10Sci'

--7--------------
select name, surname ,studentid as 'number' from students

---8-----------
select name+surname as 'Name Surname' from students

---9---------
select * from students where name like 'A%'

---10-----------
select name from books where pagecount between 50 and 200

--11------------
select * from students where name in ('Emma','Sophia','Robert')

------12-----------
select * from students where name like '[ADK]%'

----13-------------
select name,surname,class,gender from students
where (class='9Math' and gender='M') or (class='9His' and gender='F')

-----14---------
select name, surname, class, gender from students
where (sinif='10Bio' or sinif='10Math') and cinsiyet='M'

---15-------

 
select * from students
where birthdate between '01/01/1989' and '12/31/1989'