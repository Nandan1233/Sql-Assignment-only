--1-----
Create Database Order_Stores_Data 


---2----------
Create table Orders_Table ( OrderDate Date ,	Region varchar(max) , Rep varchar(max) , Order_Item varchar(max) , Units
 int , UnitCost float , Total_Price float , Order_Id int Primary key)
 Select * from Orders_Table 
 
 Drop table Orders_table
 Create table Stores_Table(Store_Id int Primary Key , StoreType varchar(max) , Assortment int , CompetitionDistance int ,
Month int , Year int ,  PromoInterval varchar(max))
Select * from Stores_Table


---3-----
 INSERT INTO Orders_Table (OrderDate,Region,Rep,Order_Item,Units,UnitCost,Total_Price,Order_Id)
 values
 ('1/6/21','East','Aruna','Pencil',95,1.99,189.05,1),
 ('1/23/21','Central','Kivell','Eraser',50,	19.99,999.50,2),
('2/9/21','Central','Ganesh',null,36, 4.99,179.64,3),
('2/26/21','Central','Payal',null,27,19.99,539.73,4),
('3/15/21','West','Sorvino',null,56, 2.99,167.44,5),
('4/1/21','East','Hitesh','Pencil',60,4.99,299.40,6),
('4/18/21','Central','Akshita',null,75,1.99,149.25,7),
('5/5/21','Central','Ruchika','Books',90,4.99,449.10,8),
('5/22/21',	'West','Surbhi',null,32,1.99,63.68,9),
('6/8/21','East','Jones','Suitcase',60,8.99,539.40,10)

INSERT INTO Stores_Table (Store_Id,StoreType,Assortment,CompetitionDistance,[Month],[Year],PromoInterval)
 values
(1,	'c',	16,	1270,	9,	2008,	'Jan'),
(2,	'a',	35,	570,11,	2007,	'Feb'),
(3,	'a',	21,	14130,	12,	2006,	'Mar'),
(4,	'c',	38,	620,	9,	2009,	null),
(5,	'a',	20,	29910,	4,	2015,	'May'),
(6,	'a',	31,	310,	12,	2013,	'June'),
(7,	'a',	37,	24000,	4,2013,	null),
(8,	'a',	18,	7520,	10,	2014,	'Aug'),
(9,	'a',	37,	2030,	8,2000,	null),
(10,'a',	50,	3160,	9,	2009,	'Oct')


 ---4---**
 ALTER TABLE Stores_Table
ADD Store_Names varchar(50)
UPDATE Stores_Table
SET Store_Names = 
case
WHEN Store_Id = 1 then 'Car' 
WHEN Store_Id = 2 then 'Bikes'
WHEN Store_Id = 3 then 'Hardware'
WHEN Store_Id = 4 then 'Electrics'
WHEN Store_Id = 5 then 'Fibers'
WHEN Store_Id = 6 then 'Elastics'
WHEN Store_Id = 7 then 'Books'
WHEN Store_Id = 8 then 'Shoes'
WHEN Store_Id = 9 then 'Clothes'
WHEN Store_Id = 10 then 'Scraps'
END
WHERE Store_Id in (1, 2, 3,4,5,6,7,8,9,10)


 --5------
ALTER TABLE Stores_Table
ADD FOREIGN KEY (Store_Id) REFERENCES Orders_Table (Order_Id)


 ----6---
 Update orders_Table Set Order_item  = case 
 when order_id = 3 then 'Compass'
 when order_id = 4 then 'Torch'
 when order_id = 5 then 'Phone'
 when order_id = 7 then 'Laptop'
 when order_id = 9 then 'Box'
 END 
 where Order_id in ( 3,4,5,7,9)


 --7---
Update  Stores_Table SET PromoInterval = 
case
WHEN Store_Id = 4 then 'Compass' 
WHEN Store_Id = 7 then 'Torch'
WHEN Store_Id = 9 then 'Phone'

END
WHERE Store_Id
 in ( 4,7,9)


 ---8-----
exec sp_rename 'Stores_Table.Assortment' , 'Store_Nos' , 'column' 

---9-----
------------Alter Table Orders_Table RENAME Column Order_Item to Item_name  AND Rep to Customers_name
exec sp_rename 'Orders_table.Order_Item' , 'Item_name' ,'column'  
exec sp_rename 'Orders_table.Rep' , 'Customers_name' ,'column'


--10------
Select UnitCost , Total_Price
 from Orders_table order by UnitCost desc , Total_Price Asc


 --11---
 exec sp_rename 'Orders_Table.Customers_name' , 'Cus_Name' ,'column'
 Select count(Cus_Name) as Cus_name   from Orders_Table group by region 


 --12---
SELECT SUM(Total_Price + UnitCost) AS TOTAL FROM Orders_Table

--13---------
select OrderDate  , UnitCost  , StoreType , Year  from Orders_Table inner join Stores_Table 
ON Orders_Table.order_id = Stores_Table.Store_id 


 --14--
 Select Order_Item  , Region from Orders_Table where Order_Id in (4 , 5, 6 ,9)


--15----
Select year from Stores_Table where CompetitionDistance
 in (29910  , 310 , 3160)

 --16---*
 Select Order_item from Orders_Table where Total_Price >= 200 AND  Total_Price <= 400
 
 --17--
Alter Table Stores_Table Rename column  CompetitionDistance To CD
Select sum(CD) from Stores_Table 

--18---
Select Count(StoreType) 
 , Count(CD) from Stores_Table

 --19-----
 Select * from Orders_Table Cross join Stores_table 

 --20-----
 Drop Table Orders_Table 
 Drop Table Stores_Table 