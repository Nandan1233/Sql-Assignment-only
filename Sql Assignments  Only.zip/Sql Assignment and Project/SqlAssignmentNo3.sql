----1-----
Drop  table EmployeeDetails
Create table EmployeeDetails(Empid int , FullName Varchar(max) , Managerid int , Dateofjoining  int     ,
city varchar(max))
insert into EmployeeDetails(Empid , FullName , Managerid , Dateofjoining  , city)
 values(121 ,'john Snow' , 321 , 01/31/2019 , 'Toronto'),
(321 , 'Walter White' , 986 , 01/30/2020 , 'California'),
(421 , 'Kuldeep Rana' , 876 , 27/11/2021 , 'New Delhi')



Create table EmployeeSalary(Empid int , Project Varchar(max) , Salary int , Variable int ) 
Insert into EmployeeSalary(Empid , Project , Salary , Variable )
Values ( 121 , 'P1' , 8000 , 500),
(321 ,'P2' , 10000 , 1000),
(421 , 'P1', 12000 ,0)

Select * from EmployeeDetails
Select * from EmployeeSalary

---------------Assignment No 1-----------------------
---1------
SELECT * FROM EmployeeDetails
MINUS
SELECT * FROM EmployeeSalary;
--2---
SELECT EmpId 
FROM EmployeeSalary 
WHERE Project IS NULL;
--3--
SELECT * FROM EmployeeDetails
WHERE DateOfJoining BETWEEN '2020/01/01'
AND '2020/12/31';

--4----
SELECT * FROM EmployeeDetails E
WHERE EXISTS
(SELECT * FROM EmployeeSalary S 
WHERE  E.EmpId = S.EmpId);

--5-----
SELECT Project, count(EmpId) EmpProjectCount
FROM EmployeeSalary
GROUP BY Project

-6-----
SELECT E.FullName, S.Salary 
FROM EmployeeDetails E 
LEFT JOIN 
EmployeeSalary S
ON E.EmpId = S.EmpId;

--7----
SELECT DISTINCT E.FullName
FROM EmployeeDetails E
INNER JOIN EmployeeDetails M
ON E.EmpID = M.ManagerID;

--8---
SELECT FullName, ManagerId, DateOfJoining, City, COUNT(*)
FROM EmployeeDetails
GROUP BY FullName, ManagerId, DateOfJoining, City
HAVING COUNT(*) > 1;

--9----
SELECT * FROM EmployeeDetails 
WHERE MOD (EmpId, 2) <> 0;

--10----
SELECT Salary
FROM EmployeeSalary Emp1
WHERE 2 = (
                SELECT COUNT( DISTINCT ( Emp2.Salary ) )
                FROM EmployeeSalary Emp2
                WHERE Emp2.Salary > Emp1.Salary
            )



---------Assignment 2------------
----1------------
SELECT  EmpId, FullName
FROM EmployeeDetails
WHERE ManagerId = 986;

--2--------
SELECT DISTINCT(Project)
FROM EmployeeSalary;

---3-----
SELECT COUNT(*) 
FROM EmployeeSalary 
WHERE Project = 'P1';

--4-----
SELECT Max(Salary), 
Min(Salary), 
AVG(Salary) 
FROM EmployeeSalary;

--5--------
SELECT EmpId, Salary
FROM EmployeeSalary
WHERE Salary BETWEEN 9000 AND 15000;

-6------
SELECT EmpId, City, ManagerId
FROM EmployeeDetails
WHERE City='Toronto' AND ManagerId='321';

--7--------
SELECT EmpId, City, ManagerId
FROM EmployeeDetails
WHERE City='California' OR ManagerId='321';

---8------------
SELECT EmpId
FROM EmployeeSalary
WHERE NOT Project='P1';

--9-----
SELECT EmpId,
Salary+Variable as TotalSalary 
FROM EmployeeSalary;

---10-----------
SELECT FullName
FROM EmployeeDetails
WHERE FullName LIKE �__hn%�;


-----Assginment No 3 ----------------------------
-----1----------
SELECT EmpId FROM EmployeeDetails
UNION 
SELECT EmpId FROM EmployeeSalary;

--2----------
SELECT * FROM EmployeeSalary
INTERSECT
SELECT * FROM ManagerSalary;

----3----------
SELECT * FROM EmployeeSalary
MINUS
SELECT * FROM ManagerSalary;

--4-------
SELECT EmpId FROM 
EmployeeDetails 
where EmpId IN 
(SELECT EmpId FROM EmployeeSalary);

--5-----
SELECT EmpId FROM 
EmployeeDetails 
where EmpId Not IN 
(SELECT EmpId FROM EmployeeSalary);

--6----
SELECT REPLACE(FullName, ' ', '-') 
FROM EmployeeDetails

---7----
SELECT INSTR(FullName, 'Snow')
FROM EmployeeDetails;

--8----
SELECT CONCAT(EmpId, ManagerId) as NewId
FROM EmployeeDetails;

--9----
SELECT SUBSTRING(FullName, 1, CHARINDEX(' ',FullName)) 
FROM EmployeeDetails;

------10-------
SELECT UPPER(FullName), LOWER(City) 
FROM EmployeeDetails;


---------Assginment No 4 -----------
--------1----------
SELECT FullName, 
LENGTH(FullName) - LENGTH(REPLACE(FullName, 'n', ''))
FROM EmployeeDetails;

--2-----
UPDATE EmployeeDetails 
SET FullName = LTRIM(RTRIM(FullName));

---3---
SELECT EmpId 
FROM EmployeeSalary 
WHERE Project IS NULL;

-4----
SELECT FullName 
FROM EmployeeDetails 
WHERE EmpId IN 
(SELECT EmpId FROM EmployeeSalary 
WHERE Salary BETWEEN 5000 AND 10000);

---5---
SELECT getdate();

-6------------
SELECT * FROM EmployeeDetails
WHERE DateOfJoining BETWEEN '2020/01/01'
AND '2020/12/31';

---7-----
SELECT * FROM EmployeeDetails E
WHERE EXISTS
(SELECT * FROM EmployeeSalary S 
WHERE  E.EmpId = S.EmpId);

-8-----
SELECT Project, count(EmpId) EmpProjectCount
FROM EmployeeSalary
GROUP BY Project
ORDER BY EmpProjectCount DESC;

---9-------
SELECT E.FullName, S.Salary 
FROM EmployeeDetails E 
LEFT JOIN 
EmployeeSalary S
ON E.EmpId = S.EmpId;

-10---------
SELECT column1, column2
FROM TableA
JOIN TableB ON TableA.Column3 = TableB.Column3
JOIN TableC ON TableA.Column4 = TableC.Column4;


----------- Advanced Assignment----------- 
--1--------
SELECT UPPER(EmpFname) AS EmpName FROM EmployeeInfo;

-2-------
SELECT COUNT(*) FROM EmployeeInfo WHERE Department = 'HR';
-3-------
SELECT GETDATE();
------4--------
SELECT SUBSTRING(EmpLname, 1, 4) FROM EmployeeInfo;
----5---------
SELECT SUBSTRING(Address, 1, CHARINDEX('(',Address)) FROM EmployeeInfo; 

---6-----------
SELECT * INTO NewTable FROM EmployeeInfo WHERE 1 = 0;

--7------
SELECT * FROM EmployeePosition WHERE Salary BETWEEN '50000' AND '100000';

----8--------
SELECT * FROM EmployeeInfo WHERE EmpFname LIKE 'S%';

--9-------
SELECT TOP N * FROM EmployeePosition ORDER BY Salary DESC;

---10---
SELECT CONCAT(EmpFname, ' ', EmpLname) AS 'FullName' FROM EmployeeInfo;

--11-------
SELECT COUNT(*), Gender FROM EmployeeInfo WHERE DOB BETWEEN '02/05/1970 ' AND '31/12/1975' GROUP BY Gender;

---12-----
SELECT * FROM EmployeeInfo ORDER BY EmpFname desc, Department asc;

--13------
SELECT * FROM EmployeeInfo WHERE EmpLname LIKE '____a';

--14-------
SELECT * FROM EmployeeInfo WHERE EmpFname NOT IN ('Sanjay','Sonia');

--15------
SELECT * FROM EmployeeInfo WHERE Address LIKE 'DELHI(DEL)%';
--16----
SELECT E.EmpFname, E.EmpLname, P.EmpPosition 
FROM EmployeeInfo E 
JOIN EmployeePosition P ON
E.EmpID = P.EmpID AND P.EmpPosition IN ('Manager');

--17-----------
SELECT Department, count(EmpID) AS EmpDeptCount 
FROM EmployeeInfo GROUP BY Department 
ORDER BY EmpDeptCount ASC;

--18---------

SELECT EmpID FROM (SELECT rowno, EmpID from EmployeeInfo) WHERE MOD(rowno,2)=0;
--19-----
SELECT * FROM EmployeeInfo E 
WHERE EXISTS 
(SELECT * FROM EmployeePosition P WHERE E.EmpId = P.EmpId);

---20-----
SELECT DISTINCT Salary FROM EmployeePosition E1 
 WHERE 2 >= (SELECTCOUNT(DISTINCT Salary)FROM EmployeePosition E2 
  WHERE E1.Salary >= E2.Salary) ORDER BY E1.Salary DESC;

  --21--------
  SELECT Salary 
FROM EmployeePosition E1 
WHERE N-1 = ( 
      SELECT COUNT( DISTINCT ( E2.Salary ) ) 
      FROM EmployeePosition E2 
      WHERE E2.Salary >  E1.Salary );
	  
 ----22-----------
 SELECT EmpID, EmpFname, Department COUNT(*) 
FROM EmployeeInfo GROUP BY EmpID, EmpFname, Department 
HAVING COUNT(*) > 1;

--23---------
Select DISTINCT E.EmpID, E.EmpFname, E.Department 
FROM EmployeeInfo E, Employee E1 
WHERE E.Department = E1.Department AND E.EmpID != E1.EmpID;

--24------
SELECT * FROM EmployeeInfo WHERE
EmpID <=3 UNION SELECT * FROM
(SELECT * FROM EmployeeInfo E ORDER BY E.EmpID DESC) 
AS E1 WHERE E1.EmpID <=3;

--25------
SELECT TOP 1 salary
FROM(
SELECT TOP 3 salary
FROM employee_table
ORDER BY salary DESC) AS emp
ORDER BY salary ASC;

--26------
SELECT * FROM EmployeeInfo WHERE EmpID = (SELECT MIN(EmpID) FROM EmployeeInfo);

------27-------
SELECT Email FROM EmployeeInfo WHERE NOT REGEXP_LIKE(Email, �[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}�, �i�);

--28-----
SELECT DEPARTMENT, COUNT(EmpID) as 'EmpNo' FROM EmployeeInfo GROUP BY DEPARTMENT HAVING COUNT(EmpD) < 2;

--29-----------
SELECT EmpPosition, SUM(Salary) from EmployeePosition GROUP BY EmpPosition;

--30-----
SELECT * 
FROM EmployeeInfo WHERE
EmpID <= (SELECT COUNT(EmpID)/2 from EmployeeInfo);


